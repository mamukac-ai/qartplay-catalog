@echo off
setlocal
chcp 65001 >nul 2>nul
title Detroit Georgian - Read-only Compatibility Check
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -Sta -ExecutionPolicy Bypass -File "%~dp0_system\Launcher.ps1" -Action Diagnose -SelectFolder
set "result=%errorlevel%"
echo.
if "%result%"=="0" (echo Compatibility check PASS.) else (echo Compatibility not confirmed. See the message above.)
echo.
pause
exit /b %result%
