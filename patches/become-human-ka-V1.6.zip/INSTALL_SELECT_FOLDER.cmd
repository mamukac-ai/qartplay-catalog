@echo off
setlocal
chcp 65001 >nul 2>nul
title Detroit Georgian - Select Game Folder
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -Sta -ExecutionPolicy Bypass -File "%~dp0_system\Launcher.ps1" -Action Install -SelectFolder
set "result=%errorlevel%"
echo.
if "%result%"=="0" (
  echo Completed.
) else (
  echo Operation not completed. See the error message above.
)
echo.
pause
exit /b %result%
