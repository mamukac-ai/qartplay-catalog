@echo off
setlocal
chcp 65001 >nul 2>nul
title Detroit Georgian - Install
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -Sta -ExecutionPolicy Bypass -File "%~dp0_system\Launcher.ps1" -Action Install %*
set "result=%errorlevel%"
echo.
if "%result%"=="0" (
  echo Completed.
) else (
  echo Installation task failed. Read the message above.
  echo Existing game files are protected by integrity checks.
)
echo.
pause
exit /b %result%
