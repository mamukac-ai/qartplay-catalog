﻿# Detroit: Become Human Georgian installer - manual and automatic folder selection.
# Windows PowerShell 5.1, no dependencies outside Windows/.NET Framework.
param(
    [ValidateSet('Install','Uninstall','Diagnose')]
    [string]$Action = 'Install',
    [switch]$SelectFolder,
    [Parameter(ValueFromRemainingArguments=$true)]
    [string[]]$GameParts
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Select-DetroitGameFolder {
    param([string]$Operation,[string]$InitialPath)

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Detroit Georgian - Game Folder'
    $form.ClientSize = New-Object System.Drawing.Size(665,208)
    $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
    $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.ShowInTaskbar = $true
    $form.TopMost = $true
    $form.Font = New-Object System.Drawing.Font('Segoe UI',10)

    $titleLabel = New-Object System.Windows.Forms.Label
    $titleLabel.Location = New-Object System.Drawing.Point(18,15)
    $titleLabel.Size = New-Object System.Drawing.Size(625,27)
    $titleLabel.Text = 'Select the Detroit: Become Human installation folder'
    $titleLabel.Font = New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold)
    $form.Controls.Add($titleLabel)

    $helpLabel = New-Object System.Windows.Forms.Label
    $helpLabel.Location = New-Object System.Drawing.Point(18,48)
    $helpLabel.Size = New-Object System.Drawing.Size(620,43)
    $helpLabel.Text = 'Choose Browse or paste the full path below. The folder must contain DetroitBecomeHuman.exe and BigFile_PC.idx. Steam is not required.'
    $form.Controls.Add($helpLabel)

    $pathBox = New-Object System.Windows.Forms.TextBox
    $pathBox.Location = New-Object System.Drawing.Point(18,99)
    $pathBox.Size = New-Object System.Drawing.Size(492,27)
    $pathBox.Text = $InitialPath
    $form.Controls.Add($pathBox)

    $browseButton = New-Object System.Windows.Forms.Button
    $browseButton.Text = 'Browse...'
    $browseButton.Location = New-Object System.Drawing.Point(521,97)
    $browseButton.Size = New-Object System.Drawing.Size(124,30)
    $form.Controls.Add($browseButton)

    $cancelButton = New-Object System.Windows.Forms.Button
    $cancelButton.Text = 'Cancel'
    $cancelButton.Location = New-Object System.Drawing.Point(521,158)
    $cancelButton.Size = New-Object System.Drawing.Size(124,32)
    $cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $form.CancelButton = $cancelButton
    $form.Controls.Add($cancelButton)

    $continueButton = New-Object System.Windows.Forms.Button
    if($Operation -eq 'Uninstall') { $continueButton.Text = 'Uninstall' }
    elseif($Operation -eq 'Diagnose') { $continueButton.Text = 'Check' }
    else { $continueButton.Text = 'Install' }
    $continueButton.Location = New-Object System.Drawing.Point(388,158)
    $continueButton.Size = New-Object System.Drawing.Size(123,32)
    $form.AcceptButton = $continueButton
    $form.Controls.Add($continueButton)

    $browseButton.Add_Click({
        $picker = New-Object System.Windows.Forms.FolderBrowserDialog
        try {
            $picker.Description = 'Select the folder containing DetroitBecomeHuman.exe'
            $picker.ShowNewFolderButton = $false
            $guess = ($pathBox.Text).Trim().Trim('"')
            if(-not [string]::IsNullOrWhiteSpace($guess) -and (Test-Path -LiteralPath $guess -PathType Container)) {
                $picker.SelectedPath = $guess
            }
            if($picker.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
                $pathBox.Text = $picker.SelectedPath
            }
        } finally { $picker.Dispose() }
    })

    $continueButton.Add_Click({
        $candidate = ($pathBox.Text).Trim().Trim('"')
        if(-not [string]::IsNullOrWhiteSpace($candidate) -and
            (Test-Path -LiteralPath (Join-Path $candidate 'DetroitBecomeHuman.exe') -PathType Leaf) -and
            (Test-Path -LiteralPath (Join-Path $candidate 'BigFile_PC.idx') -PathType Leaf)) {
            $form.Tag = $candidate
            $form.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $form.Close()
        } else {
            [void][System.Windows.Forms.MessageBox]::Show(
                $form,
                'Wrong folder. Choose the directory containing both DetroitBecomeHuman.exe and BigFile_PC.idx.',
                'Game files not found',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            $pathBox.Focus()
        }
    })

    try {
        $dialogResult = $form.ShowDialog()
        if($dialogResult -ne [System.Windows.Forms.DialogResult]::OK) {
            throw 'Folder selection canceled. No game files were changed.'
        }
        return [string]$form.Tag
    } finally {
        $form.Dispose()
    }
}

try {
    $GamePath = ($GameParts -join ' ').Trim().Trim('"')
    $Engine = Join-Path $PSScriptRoot 'DBHInstaller.cs'
    if(-not (Test-Path -LiteralPath $Engine -PathType Leaf)) {
        throw 'Installer files are missing. Extract the entire archive before running INSTALL.cmd.'
    }
    if($PSVersionTable.PSVersion.Major -lt 5) {
        throw 'Windows PowerShell 5.1 or later is required.'
    }

    Write-Host ('Detroit Georgian v1.6 - ' + $Action)
    Write-Host 'Offline localization installer. Steam is NOT required to select a game folder.'
    Add-Type -Path $Engine -ReferencedAssemblies @('System.dll','System.Core.dll','System.Web.Extensions.dll','System.IO.Compression.dll') -ErrorAction Stop

    $stateFolder = Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) 'DetroitGeorgianInstaller'
    $stateFile = Join-Path $stateFolder 'last_game_folder.txt'
    $rememberedPath = ''
    if(Test-Path -LiteralPath $stateFile -PathType Leaf) {
        try { $rememberedPath = [IO.File]::ReadAllText($stateFile,[Text.Encoding]::UTF8).Trim() }
        catch { $rememberedPath = '' }
    }

    # Precedence: command-line argument > explicit chooser > remembered location > auto-detect.
    if(-not [string]::IsNullOrWhiteSpace($GamePath)) {
        $GamePath = [DBHInstaller]::DetectGame($PSScriptRoot,$GamePath)
    } elseif($SelectFolder) {
        $GamePath = Select-DetroitGameFolder -Operation $Action -InitialPath $rememberedPath
    } else {
        if(-not [string]::IsNullOrWhiteSpace($rememberedPath)) {
            try { $GamePath = [DBHInstaller]::DetectGame($PSScriptRoot,$rememberedPath) }
            catch { $GamePath = '' }
        }
        if([string]::IsNullOrWhiteSpace($GamePath)) {
            $GamePath = [DBHInstaller]::DetectGame($PSScriptRoot,'')
        }
        if([string]::IsNullOrWhiteSpace($GamePath)) {
            Write-Host 'Game not found automatically. Opening the folder selection window.' -ForegroundColor Yellow
            $GamePath = Select-DetroitGameFolder -Operation $Action -InitialPath $rememberedPath
        }
    }

    # v1.6: unknown index SHA is accepted ONLY after a read-only check of all
    # localization rows, archive offsets, and the font resource. Untranslated
    # source labels are preserved; they no longer produce false mismatches.
    # Failures are
    # fail-closed; neither diagnose nor a failed install changes game files.
    if($Action -eq 'Diagnose') {
        [DBHInstaller]::Diagnose($PSScriptRoot,$GamePath)
    } else {
        [DBHInstaller]::Run($PSScriptRoot,$Action,$GamePath)
    }
    try {
        if(-not (Test-Path -LiteralPath $stateFolder -PathType Container)) {
            [void](New-Item -ItemType Directory -Path $stateFolder -Force)
        }
        [IO.File]::WriteAllText($stateFile,$GamePath,(New-Object System.Text.UTF8Encoding($false)))
    } catch {
        Write-Host 'Note: Could not remember the game folder for the next launch.' -ForegroundColor Yellow
    }
    exit 0
} catch {
    $failure = $_.Exception
    while($null -ne $failure.InnerException) { $failure = $failure.InnerException }
    Write-Host ('ERROR: ' + $failure.Message) -ForegroundColor Red
    if($failure.Message -match 'differs|Unrecognized|incompatible|not compatible|d30|Missing game archive|resource') {
        Write-Host 'Compatibility could not be confirmed. Send your original BigFile_PC.idx for version-specific support.' -ForegroundColor Yellow
        Write-Host 'No existing game files were deliberately replaced by the compatibility audit.' -ForegroundColor Yellow
    }
    exit 1
}
