// Detroit Georgian Installer - Windows PowerShell 5.1 / .NET Framework
// Local installer. No downloads, online services, or administrator privileges required.
// The translation and font assets are byte-for-byte unchanged from working baseline.
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using Microsoft.Win32;

public static class DBHInstaller {
    const int HeaderSize=116, RecordSize=28, FontId=1420, MaxBlob=16*1024*1024, MaxIndex=15*1024*1024;
    const string IndexName="BigFile_PC.idx", ArchiveName="BigFile_PC.d30", BackupName="DBH_GE_Public_Backup";
    const string FontSha="07f8192f7b7d51682cf863045164d56dcce882ec8aaf62d118cc1ffdd0e1242c";
    const string TranslationSha="bdaa5d16d1f2f9d9eaecfc77035c86f5105faa1a39bf5f20e303fec376168fe2";
    static readonly Dictionary<string,string[]> Known=new Dictionary<string,string[]>(StringComparer.OrdinalIgnoreCase){
      {"e1a97a33ae8c9e651266dc2370aa5e18b64db697bc83b77f16c84031b62c36a4", new []{"clean", ""}},
      {"1ddd361b7e70370bc69f62a9d35eb761f66375e7526643b10b72eefc333ecdfc", new []{"trial-0.3", "e2ac58dbc798d0fa7cf0a76c94048181d349ed88af63239ca75c5ffe1fd451b4"}},
      {"601ea69bdc663e2499c1cb910c44b101adeb7c4f9f06dda8c0cb9a3023cacdf9", new []{"trial-0.4", "d41e6b93d72c522d0cca2f526a227c630bcf901c9aa9ef182bfdb332aa84ce11"}},
      {"5227bfabbd82871f475bfd360a0915b66be65091aae0f3e5c5914f991eaa9c5f", new []{"trial-0.5", "e7add1932f022ce609cb2350ca0367518668625c0c97d483a220149dd499547d"}},
      {"e5b556b4af56f49b5e9f427386674132fd82235ba5142811d55e129da4509243", new []{"trial-0.6", "0394eb20d6a66c619b4e80b69be25b318fd20580afa9e02b2cc1e7b3b6a9a224"}}
    };
    static readonly UTF8Encoding Utf8=new UTF8Encoding(false,true);
    static readonly UnicodeEncoding Utf16=new UnicodeEncoding(false,false,true);
    static readonly JavaScriptSerializer Json=new JavaScriptSerializer(){MaxJsonLength=64*1024*1024,RecursionLimit=128};
    static readonly Regex SteamLibrary=new Regex("\"path\"\\s*\"([^\"]+)\"",RegexOptions.IgnoreCase);
    static string BaseDir;
    class TextRow {public string Key,English,Georgian; public uint Flag;}
    class Parsed {public int SizePos,LocLen,EngStart,EngEnd; public List<TextRow> Rows;}
    class IndexRow {public uint Offset,Length; public byte Volume;}
    class WorkResult {public byte[] Index;public int Resources,Changes,IndexCount;}

    static void Need(bool ok,string msg){if(!ok)throw new InvalidOperationException(msg);}
    static string Digest(byte[] bytes){using(var sha=SHA256.Create()){return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-","").ToLowerInvariant();}}
    static string DigestFile(string file){using(var sha=SHA256.Create())using(var f=File.OpenRead(file)){return BitConverter.ToString(sha.ComputeHash(f)).Replace("-","").ToLowerInvariant();}}
    static uint U32(byte[] b,int p){Need(p>=0 && p<=b.Length-4,"Truncated resource integer");return BitConverter.ToUInt32(b,p);}
    static uint Be32(byte[] b,int p){return ((uint)b[p]<<24)|((uint)b[p+1]<<16)|((uint)b[p+2]<<8)|b[p+3];}
    static void PutU32(byte[] b,int p,uint val){byte[] n=BitConverter.GetBytes(val);Buffer.BlockCopy(n,0,b,p,4);}
    static void PutBE32(byte[] b,int p,uint val){b[p]=(byte)(val>>24);b[p+1]=(byte)(val>>16);b[p+2]=(byte)(val>>8);b[p+3]=(byte)val;}
    static bool Ge(string x){foreach(char c in x){if(c>=0x10a0 && c<=0x10ff || c>=0x1c90 && c<=0x1cbf)return true;}return false;}
    // The extraction reference included 1,301 already-localized entries.
    // Allow clean English in those entries on an index-SHA256-approved build,
    // while keeping source, key and flag checks strict on other entries.
    // Some game releases use different labels for optional languages (for example
    // GUI_MENU_OPTIONS_LANGUAGES_CHI). A blank/non-Georgian translation target
    // means the installer never modifies that string. Comparing such a value to
    // an older reference was a false incompatibility, not a safety check.
    static bool WillTranslate(string target){return !string.IsNullOrEmpty(target) && Ge(target);}
    static bool EnglishCompatible(string actual,string reference,string target,bool strict){
        if(!WillTranslate(target))return true; // Preserved byte-for-byte from this game's source.
        return !strict || actual==reference || Ge(reference);
    }
    static bool HasHead(byte[] b,int p,string s){if(p<0||p>b.Length-s.Length)return false;for(int i=0;i<s.Length;i++)if(b[p+i]!=(byte)s[i])return false;return true;}
    static int FindEnglish(byte[] b,int start,int end){byte[] needle=new byte[]{1,3,0,0,0,69,78,71};for(int p=start;p<=end-needle.Length;p++){if(b[p]==1 && b[p+1]==3){int i=0;while(i<needle.Length && b[p+i]==needle[i])i++;if(i==needle.Length)return p;}}return -1;}
    static IndexRow Entry(byte[] index,int id){long p=(long)HeaderSize+((long)RecordSize*id);Need(p>=0 && p+RecordSize<=index.Length,"Index entry out of range: "+id);int at=(int)p;return new IndexRow{Offset=Be32(index,at+1),Length=Be32(index,at+5),Volume=index[at+16]};}
    static void SetEntry(byte[] index,int id,uint off,uint len,byte volume){int p=HeaderSize+RecordSize*id;PutBE32(index,p+1,off);PutBE32(index,p+5,len);index[p+16]=volume;}
    static Parsed Parse(byte[] src){
        Need(src.Length>=54 && HasHead(src,0,"COM_CONT"),"Invalid COM_CONT resource");
        uint kind=U32(src,8);Need(kind==5 || kind==6,"Unknown COM_CONT version: "+kind);
        uint initial=U32(src,12);long anchor=16L+initial;
        Need(initial<=1048576 && anchor+16<=src.Length && HasHead(src,(int)anchor,"LOADCONT"),"Invalid LOADCONT header");
        uint load=U32(src,(int)anchor+12);Need(load<=4096,"Oversized LOADCONT");
        long loc=anchor+16L+load;
        Need(loc+16<=src.Length && HasHead(src,(int)loc,"LOCALIZ_"),"Invalid LOCALIZ_ resource");
        uint ver=U32(src,(int)loc+8);Need(ver==5||ver==6,"Unsupported LOCALIZ_ version");
        int sizepos=(int)loc+12;uint loclen=U32(src,sizepos);long start=(long)sizepos+4, end=start+loclen;
        Need(loclen<=MaxBlob && end<=src.Length,"Invalid LOCALIZ_ size");
        int pos=(int)start+(ver==5?1:0);
        if(ver==5)Need(src[(int)start]==0,"Unexpected v5 prefix");
        uint nlangs=U32(src,pos);Need(nlangs>=1 && nlangs<=64,"Invalid language count");
        int langpos=FindEnglish(src,pos+4,(int)end);Need(langpos>=0,"English language segment missing");
        int countpos=langpos+8;uint count=U32(src,countpos);Need(count<=100000,"Unreasonable text count");
        int engstart=countpos+4;
        pos=engstart;var rows=new List<TextRow>((int)count);
        for(int i=0;i<count;i++){
            uint keylen=U32(src,pos);pos+=4;
            Need(keylen>0 && keylen<10000 && (long)pos+keylen<=end,"Invalid key length");
            string key=Utf8.GetString(src,pos,(int)keylen);pos+=(int)keylen;
            uint textlen=U32(src,pos);pos+=4;
            Need(textlen<=4000000 && textlen%2==0 && (long)pos+textlen<=end,"Invalid text length");
            string txt=Utf16.GetString(src,pos,(int)textlen);pos+=(int)textlen;
            uint flag=U32(src,pos);pos+=4;
            rows.Add(new TextRow{Key=key,English=txt,Flag=flag});
        }
        Need(pos+4<=end,"Missing localization table terminator");
        return new Parsed{SizePos=sizepos,LocLen=(int)loclen,EngStart=engstart,EngEnd=pos,Rows=rows};
    }
    static bool BytesEqual(byte[] a,int aoff,byte[] b,int boff,int len){if(aoff<0||boff<0||len<0||aoff+len>a.Length||boff+len>b.Length)return false;for(int i=0;i<len;i++)if(a[aoff+i]!=b[boff+i])return false;return true;}
    static byte[] Build(byte[] source,List<TextRow> expected,bool strict,out int changes){
        Parsed src=Parse(source);Need(src.Rows.Count==expected.Count,"Localization entry count changed");
        changes=0;
        using(var ms=new MemoryStream(source.Length+4096))using(var w=new BinaryWriter(ms,Encoding.UTF8,true)){
            ms.Write(source,0,src.EngStart);
            for(int i=0;i<src.Rows.Count;i++){
                TextRow old=src.Rows[i],exp=expected[i];
                Need(old.Key==exp.Key && old.Flag==exp.Flag,"Localization key/flag differs: "+old.Key);
                // Some extraction references were created while the older Georgian trial
                // was active. Their recorded "English" slot already contains Georgian.
                // A clean, WHITELISTED game build legitimately has the original English
                // string in that position. Never confuse that with a game-version change.
                // We still require exact row count, key, flag, and the approved index hash.
                Need(EnglishCompatible(old.English,exp.English,exp.Georgian,strict),"Original English resource changed: "+old.Key);
                string translated=(!string.IsNullOrEmpty(exp.Georgian) && Ge(exp.Georgian))?exp.Georgian:old.English;
                if(translated!=old.English)changes++;
                byte[] kb=Utf8.GetBytes(old.Key),tb=Utf16.GetBytes(translated);
                w.Write((uint)kb.Length);w.Write(kb);w.Write((uint)tb.Length);w.Write(tb);w.Write(old.Flag);
            }
            if(changes==0)return source;
            int engendnew=(int)ms.Position;
            ms.Write(source,src.EngEnd,source.Length-src.EngEnd);
            byte[] result=ms.ToArray();
            long delta=(long)result.Length-source.Length;long nlen=(long)src.LocLen+delta;
            Need(nlen>=0 && nlen<=uint.MaxValue,"Localization length overflow");
            PutU32(result,src.SizePos,(uint)nlen);
            Parsed reread=Parse(result);
            Need(reread.Rows.Count==src.Rows.Count,"Serialization QA: row count changed");
            Need(BytesEqual(result,0,source,0,src.SizePos) && BytesEqual(result,src.SizePos+4,source,src.SizePos+4,src.EngStart-(src.SizePos+4)),"Serialization QA: metadata changed");
            Need(BytesEqual(result,reread.EngEnd,source,src.EngEnd,source.Length-src.EngEnd),"Serialization QA: other languages changed");
            for(int i=0;i<reread.Rows.Count;i++){
                TextRow r=reread.Rows[i],o=src.Rows[i],e=expected[i];
                string expectedGe=(!string.IsNullOrEmpty(e.Georgian)&&Ge(e.Georgian))?e.Georgian:o.English;
                Need(r.Key==o.Key && r.Flag==o.Flag && r.English==expectedGe,"Serialization QA: text mismatch");
            }
            return result;
        }
    }
    static Dictionary<int,List<TextRow>> LoadRows(string package){
        Need(DigestFile(package)==TranslationSha,"Packaged translations failed SHA256 integrity check");
        string json;
        using(var f=File.OpenRead(package))using(var gz=new GZipStream(f,CompressionMode.Decompress))using(var sr=new StreamReader(gz,Utf8)){json=sr.ReadToEnd();}
        var root=(Dictionary<string,object>)Json.DeserializeObject(json);
        var groups=(IList)root["resources"];
        var map=new Dictionary<int,List<TextRow>>();
        foreach(object obj in groups){
            var group=(IList)obj;int rid=Convert.ToInt32(group[0],CultureInfo.InvariantCulture);
            Need(!map.ContainsKey(rid),"Duplicate resource id: "+rid);
            var rows=new List<TextRow>();var keys=new HashSet<string>(StringComparer.Ordinal);
            foreach(object v in (IList)group[1]){
                var d=(IList)v;string key=(string)d[0];Need(keys.Add(key),"Duplicate key: "+key);
                rows.Add(new TextRow{Key=key,English=(string)d[1],Georgian=(string)d[2],Flag=Convert.ToUInt32(d[3],CultureInfo.InvariantCulture)});
            }
            map.Add(rid,rows);
        }
        Need(map.Count==1294,"Unexpected text resource count");
        return map;
    }
    static Dictionary<string,object> ReadJson(string path){return (Dictionary<string,object>)Json.DeserializeObject(File.ReadAllText(path,Utf8));}
    static string S(Dictionary<string,object> state,string key){object v;return state.TryGetValue(key,out v) && v!=null?Convert.ToString(v,CultureInfo.InvariantCulture):null;}
    static void SaveJson(string path,Dictionary<string,object> obj){
        string stage=path+".tmp";File.WriteAllText(stage,Json.Serialize(obj),new UTF8Encoding(false));
        if(File.Exists(path))File.Replace(stage,path,null);else File.Move(stage,path);
    }
    static void CheckNotRunning(){
        try{if(Process.GetProcessesByName("DetroitBecomeHuman").Length>0)throw new InvalidOperationException("Close Detroit: Become Human before editing game files.");}
        catch(System.ComponentModel.Win32Exception){throw new InvalidOperationException("Cannot verify that game is closed. Close game and try again.");}
    }
    static string VolumePath(string game,int number){return Path.Combine(game,number==0?"BigFile_PC.dat":("BigFile_PC.d"+number.ToString("00",CultureInfo.InvariantCulture)));}
    static void ReplaceFile(string source,string dest){if(File.Exists(dest))File.Replace(source,dest,null);else File.Move(source,dest);}
    static void CopyVerified(string source,string dest,string expected){File.Copy(source,dest,true);Need(DigestFile(dest)==expected,"Backup checksum failed: "+dest);}
    static string Stage(string game,string ext){return Path.Combine(game,".dbh-ge-"+Guid.NewGuid().ToString("N")+ext);}
    static Dictionary<string,object> State(string folder){string f=Path.Combine(folder,"install_state.json");return File.Exists(f)?ReadJson(f):null;}
    // Unknown index SHA256 is not by itself an incompatibility: offline/non-Steam
    // distributions may have different index metadata. Only an actual, complete
    // read-only content audit can authorize installation on an unknown index.
    // No user-facing "force install" option exists: failed audits NEVER write to
    // game files. If d30 already exists on an unrecognized build, it may belong
    // to another mod or to the game, and must not be overwritten.
    static byte[] ReadResource(string game,byte[] index,int rid,Dictionary<int,FileStream> handles){
        IndexRow ent=Entry(index,rid);
        Need(ent.Volume<=30 && ent.Length<=MaxBlob && ent.Length>=54,"Invalid resource index entry: "+rid);
        FileStream stream;
        if(!handles.TryGetValue(ent.Volume,out stream)){
            string archive=VolumePath(game,ent.Volume);
            Need(File.Exists(archive),"Missing game archive (resource "+rid+"): "+archive);
            stream=File.OpenRead(archive);handles.Add(ent.Volume,stream);
        }
        Need((long)ent.Offset+ent.Length<=stream.Length,"Resource offset outside archive: "+rid);
        byte[] data=new byte[(int)ent.Length];stream.Position=ent.Offset;
        int got=0;
        while(got<data.Length){int n=stream.Read(data,got,data.Length-got);Need(n>0,"Incomplete resource read: "+rid);got+=n;}
        return data;
    }
    static bool HasBytes(byte[] data,string value){
        byte[] pattern=Encoding.ASCII.GetBytes(value);
        for(int p=0;p<=data.Length-pattern.Length;p++)if(HasHead(data,p,value))return true;
        return false;
    }
    static void AuditUnknown(string game,byte[] index,Dictionary<int,List<TextRow>> mapping){
        string d30=Path.Combine(game,ArchiveName);
        Need(!File.Exists(d30),"This unrecognized build already has BigFile_PC.d30. It might contain a mod or game data. Refusing to replace it. No game files changed.");
        Console.WriteLine("Unrecognized index checksum. Running full READ-ONLY compatibility audit...");
        int resourceCount=0,textCount=0,preservedVariants=0,translatedSourceMismatches=0;
        var sampleMismatches=new List<string>();
        var streams=new Dictionary<int,FileStream>();
        try{
            foreach(var item in mapping.OrderBy(x=>x.Key)){
                int rid=item.Key;
                Need(Entry(index,rid).Volume!=30,"Localization resource uses archive d30, which is absent: "+rid);
                byte[] bytes=ReadResource(game,index,rid,streams);
                Parsed parsed=Parse(bytes);
                List<TextRow> expected=item.Value;
                Need(parsed.Rows.Count==expected.Count,"Localization row count differs in resource "+rid+" (game "+parsed.Rows.Count+", package "+expected.Count+")");
                for(int k=0;k<expected.Count;k++){
                    TextRow actual=parsed.Rows[k], exp=expected[k];
                    Need(actual.Key==exp.Key && actual.Flag==exp.Flag,"Localization key/flag differs in resource "+rid+", row "+k);
                    // A non-Georgian/empty target is never overwritten: preserve
                    // the actual text in the running game, regardless of which
                    // release's language abbreviation/label it contains.
                    if(!WillTranslate(exp.Georgian)){
                        if(actual.English!=exp.English)preservedVariants++;
                        textCount++;
                        continue;
                    }
                    // For strings that WILL be changed, keep strict comparison
                    // against a trustworthy original. Some reference "English"
                    // slots were captured after the old Georgian trial was active;
                    // allow an unmodified (non-Georgian) source in those slots.
                    bool same=actual.English==exp.English;
                    bool compatible=Ge(exp.English)
                        ? same || (!Ge(actual.English) && !string.IsNullOrEmpty(actual.English))
                        : same;
                    if(!compatible){
                        translatedSourceMismatches++;
                        if(sampleMismatches.Count<15)sampleMismatches.Add(
                            "Resource "+rid+" / "+exp.Key+" (targeted translated string differs)");
                    }
                    textCount++;
                }
                resourceCount++;
                if(resourceCount%300==0)Console.WriteLine("Checked "+resourceCount+" / "+mapping.Count+" localization resources...");
            }
            if(translatedSourceMismatches>0){
                Console.WriteLine("FAIL: "+translatedSourceMismatches+" translated text source mismatch(es) found:");
                foreach(string mismatch in sampleMismatches)Console.WriteLine("  - "+mismatch);
                Need(false,"Compatibility failed for "+translatedSourceMismatches+" translated source entries. "+
                    "Untranslated language labels were ignored safely. No files changed.");
            }
            IndexRow f=Entry(index,FontId);
            Need(f.Volume!=30 && f.Length>=100 && f.Length<=MaxBlob,"Font resource slot is missing or not compatible");
            byte[] fontSource=ReadResource(game,index,FontId,streams);
            Need(HasHead(fontSource,0,"QZIP") && HasBytes(fontSource,"COM_CONT") && HasBytes(fontSource,"FONT_MASTER_ENG.gfx"),
                "Font resource ID 1420 is not the expected English font type");
            Console.WriteLine("PASS: "+resourceCount+" resource layouts, "+textCount+" rows, font resource, and source archive pointers validated.");
            Console.WriteLine("Preserved "+preservedVariants+" source-text variant(s) in entries that the Georgian installer does not translate.");
        } finally { foreach(FileStream stream in streams.Values)stream.Dispose(); }
    }
    static void AssertVersion(byte[] idx,string game,Dictionary<int,List<TextRow>> mapping,out string name,out string idxhash){
        idxhash=Digest(idx);string[] known;
        string existing=Path.Combine(game,ArchiveName);
        if(Known.TryGetValue(idxhash,out known)){
            name=known[0];
            if(known[1]=="")Need(!File.Exists(existing),"Unknown BigFile_PC.d30 exists. This may be another mod; no files changed.");
            else Need(File.Exists(existing) && DigestFile(existing)==known[1],"Known index found, but d30 archive differs; no files changed.");
            Console.WriteLine("Approved original index SHA256: "+idxhash);
            return;
        }
        Console.WriteLine("Unrecognized index SHA256: "+idxhash);
        AuditUnknown(game,idx,mapping);
        name="structurally-verified-"+idxhash.Substring(0,12);
    }
    static WorkResult Assemble(string game,byte[] index,Dictionary<int,List<TextRow>> mapping,byte[] font,byte[] header,string stage){
        var result=new WorkResult{Index=(byte[])index.Clone(),Resources=0,Changes=0,IndexCount=0};
        var handles=new Dictionary<int,FileStream>();
        var ids=mapping.Keys.ToList();ids.Add(FontId);ids=ids.Distinct().OrderBy(x=>x).ToList();
        try{
            using(var output=new FileStream(stage,FileMode.CreateNew,FileAccess.Write,FileShare.None)){
                output.Write(header,0,header.Length);
                int done=0;
                foreach(int rid in ids){
                    byte[] patched;int changed=0;
                    if(rid==FontId)patched=font;
                    else{
                        IndexRow source=Entry(index,rid);
                        Need(source.Volume<=30 && source.Length<=MaxBlob && source.Length>=54,"Invalid source resource metadata: "+rid);
                        FileStream f;
                        if(!handles.TryGetValue(source.Volume,out f)){
                            string archive=VolumePath(game,source.Volume);
                            Need(File.Exists(archive),"Missing original game archive: "+archive);
                            f=File.OpenRead(archive);handles[source.Volume]=f;
                        }
                        Need((long)source.Offset+source.Length<=f.Length,"Resource beyond archive: "+rid);
                        f.Position=(long)source.Offset;byte[] raw=new byte[(int)source.Length];int got=0;
                        while(got<raw.Length){int n=f.Read(raw,got,raw.Length-got);Need(n>0,"Short resource read: "+rid);got+=n;}
                        patched=Build(raw,mapping[rid],source.Volume!=30,out changed);
                        result.Changes+=changed;if(changed>0)result.Resources++;
                    }
                    long gap=(2048-(output.Position%2048))%2048;
                    if(gap>0){byte[] zero=new byte[(int)gap];output.Write(zero,0,zero.Length);}
                    Need(output.Position<=uint.MaxValue && patched.LongLength<=uint.MaxValue,"Index offset overflow");
                    SetEntry(result.Index,rid,(uint)output.Position,(uint)patched.Length,30);
                    output.Write(patched,0,patched.Length);done++;
                    if(done%150==0)Console.WriteLine("Prepared resource "+done+" / "+ids.Count);
                }
            }
            // Prove each modified index record changed ONLY the position, length and volume.
            byte[] masked=(byte[])result.Index.Clone();
            foreach(int rid in ids){int p=HeaderSize+RecordSize*rid;Buffer.BlockCopy(index,p+1,masked,p+1,8);masked[p+16]=index[p+16];}
            Need(masked.SequenceEqual(index),"QA: index bytes outside permitted fields changed");
            using(var output=File.OpenRead(stage)){
                var check=ids.Where(id=>id!=FontId).Where((id,i)=>i%41==0).ToList();check.Add(FontId);
                foreach(int rid in check){
                    var ent=Entry(result.Index,rid);Need(ent.Volume==30,"QA: wrong archive number");
                    Need((long)ent.Offset+ent.Length<=output.Length,"QA: invalid new archive pointer");
                    output.Position=(long)ent.Offset;byte[] data=new byte[(int)ent.Length];int got=0;
                    while(got<data.Length){int n=output.Read(data,got,data.Length-got);Need(n>0,"QA: short generated archive read");got+=n;}
                    if(rid==FontId)Need(Digest(data)==FontSha,"QA: font changed");
                    else Need(Parse(data).Rows.Count==mapping[rid].Count,"QA: translated resource row count differs");
                }
            }
            result.IndexCount=ids.Count;return result;
        }finally{foreach(FileStream f in handles.Values)f.Dispose();}
    }
    static void Rollback(string game,Dictionary<string,object> state){
        string backup=Path.Combine(game,BackupName),idx=Path.Combine(game,IndexName),d30=Path.Combine(game,ArchiveName);
        string idxOrig=Path.Combine(backup,"original_BigFile_PC.idx"),d30Orig=Path.Combine(backup,"original_BigFile_PC.d30");
        string idxBefore=S(state,"original_idx_sha256"),idxAfter=S(state,"installed_idx_sha256");
        string d30Before=S(state,"original_d30_sha256"),d30After=S(state,"installed_d30_sha256");
        Need(File.Exists(idxOrig) && DigestFile(idxOrig)==idxBefore,"Original index backup missing or damaged");
        if(d30Before!=null)Need(File.Exists(d30Orig) && DigestFile(d30Orig)==d30Before,"Original d30 backup missing or damaged");
        string presentIdx=File.Exists(idx)?DigestFile(idx):null;
        string presentD30=File.Exists(d30)?DigestFile(d30):null;
        Need(presentIdx==idxBefore || presentIdx==idxAfter,"Index modified by another program; refusing overwrite");
        Need(presentD30==d30Before || presentD30==d30After,"d30 modified by another program; refusing overwrite");
        string staging=Stage(game,".restore.idx");
        try{
            File.Copy(idxOrig,staging,false);ReplaceFile(staging,idx);
            if(d30Before==null){if(File.Exists(d30))File.Delete(d30);}
            else{string restoreD30=Stage(game,".restore.d30");try{File.Copy(d30Orig,restoreD30,false);ReplaceFile(restoreD30,d30);}finally{if(File.Exists(restoreD30))File.Delete(restoreD30);}}
            state["status"]="rolled_back";SaveJson(Path.Combine(backup,"install_state.json"),state);
            Console.WriteLine("SUCCESS: Original game index and d30 restored.");
        }finally{if(File.Exists(staging))File.Delete(staging);}
    }
    static bool CheckAlreadyInstalled(string game){
        var state=State(Path.Combine(game,BackupName));if(state==null)return false;
        if(S(state,"status")=="installed"){
            string idx=Path.Combine(game,IndexName),d30=Path.Combine(game,ArchiveName);
            Need(DigestFile(idx)==S(state,"installed_idx_sha256"),"Installed public mod index changed. Investigate before continuing.");
            Need(File.Exists(d30) && DigestFile(d30)==S(state,"installed_d30_sha256"),"Installed public mod archive changed. Investigate before continuing.");
            Console.WriteLine("Public Georgian mod is already installed; no changes needed.");return true;
        }
        Need(S(state,"status")=="uninstalled" || S(state,"status")=="rolled_back","Interrupted installation found; run UNINSTALL.cmd first to restore the game.");
        return false;
    }
    static void Install(string game){
        CheckNotRunning();if(CheckAlreadyInstalled(game))return;
        string assets=Path.Combine(BaseDir,"enginedata"),idx=Path.Combine(game,IndexName),d30=Path.Combine(game,ArchiveName);
        byte[] font=File.ReadAllBytes(Path.Combine(assets,"font_resource.bin"));
        Need(Digest(font)==FontSha,"Font asset changed or damaged");
        byte[] header=File.ReadAllBytes(Path.Combine(assets,"d30_header.bin"));
        Need(header.Length==2048 && HasHead(header,0,"QUANTICDREAMTABINDEX"),"Invalid packaged archive header");
        var mapping=LoadRows(Path.Combine(assets,"translation_data.json.gz"));
        byte[] source=File.ReadAllBytes(idx);Need(source.Length<=MaxIndex && HasHead(source,0,"QUANTICDREAMTABINDEX"),"Invalid game index");
        string kind,sourceSha;AssertVersion(source,game,mapping,out kind,out sourceSha);Console.WriteLine("Supported source build: "+kind);
        string backup=Path.Combine(game,BackupName);Directory.CreateDirectory(backup);
        var oldState=State(backup);Need(oldState!=null || Directory.GetFiles(backup).Length==0,"Unrecognized files in backup directory");
        string stageD=Stage(game,".d30"),stageI=Stage(game,".idx");
        try{
            Console.WriteLine("Building Georgian archive from LOCAL game files. No Internet required...");
            var made=Assemble(game,source,mapping,font,header,stageD);
            File.WriteAllBytes(stageI,made.Index);
            string originalD30=File.Exists(d30)?DigestFile(d30):null;
            string idxBackup=Path.Combine(backup,"original_BigFile_PC.idx"),d30Backup=Path.Combine(backup,"original_BigFile_PC.d30");
            CopyVerified(idx,idxBackup,sourceSha);
            if(originalD30!=null)CopyVerified(d30,d30Backup,originalD30);
            else if(File.Exists(d30Backup))File.Delete(d30Backup);
            var state=new Dictionary<string,object>();
            state["status"]="prepared";state["package"]="Detroit Georgian v1.6 verified offline";
            state["source_kind"]=kind;state["original_idx_sha256"]=sourceSha;state["original_d30_sha256"]=originalD30;
            state["installed_idx_sha256"]=DigestFile(stageI);state["installed_d30_sha256"]=DigestFile(stageD);
            state["translated_resources"]=made.Resources;state["changed_text_occurrences"]=made.Changes;
            state["source_archives_not_modified"]=true;state["date_utc"]=DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ",CultureInfo.InvariantCulture);
            string statepath=Path.Combine(backup,"install_state.json");SaveJson(statepath,state);
            ReplaceFile(stageD,d30);ReplaceFile(stageI,idx);
            Need(DigestFile(idx)==S(state,"installed_idx_sha256") && DigestFile(d30)==S(state,"installed_d30_sha256"),"Final checksum check failed; run UNINSTALL.cmd to restore the game");
            state["status"]="installed";SaveJson(statepath,state);
            Console.WriteLine("SUCCESS: Georgian localization installed. TEXT LANGUAGE: ENGLISH; SUBTITLES: ON.");
            Console.WriteLine("Changed text occurrences: "+made.Changes+". Backup: "+backup);
        }catch(Exception error){
            Console.WriteLine("INSTALL ERROR: "+error.Message);
            var pending=State(backup);
            if(pending!=null && S(pending,"status")=="prepared"){
                try{Rollback(game,pending);}catch(Exception recovery){Console.WriteLine("RESTORE WARNING: "+recovery.Message+". Run UNINSTALL.cmd.");}
            }
            throw;
        }finally{if(File.Exists(stageD))File.Delete(stageD);if(File.Exists(stageI))File.Delete(stageI);}
    }
    static void Uninstall(string game){
        CheckNotRunning();string backup=Path.Combine(game,BackupName);
        var state=State(backup);Need(state!=null,"No public mod installation record; no files changed.");
        if(S(state,"status")=="uninstalled" || S(state,"status")=="rolled_back"){Console.WriteLine("Already uninstalled.");return;}
        if(S(state,"status")=="prepared"){
            Rollback(game,state);
            Console.WriteLine("Interrupted installation restored.");
            return;
        }
        Need(S(state,"status")=="installed","Unknown installation state; no files changed.");
        Need(DigestFile(Path.Combine(game,IndexName))==S(state,"installed_idx_sha256"),"Installed game index changed; uninstall blocked.");
        string d30=Path.Combine(game,ArchiveName);
        Need(File.Exists(d30) && DigestFile(d30)==S(state,"installed_d30_sha256"),"Installed game archive changed; uninstall blocked.");
        Rollback(game,state);
        state["status"]="uninstalled";SaveJson(Path.Combine(backup,"install_state.json"),state);
        Console.WriteLine("Uninstall complete.");
    }
    static IEnumerable<string> CandidateRoots(){
        yield return Environment.CurrentDirectory;yield return BaseDir;
        string local=Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
        if(!string.IsNullOrEmpty(local))yield return Path.Combine(local,"Steam");
        local=Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        if(!string.IsNullOrEmpty(local))yield return Path.Combine(local,"Steam");
        foreach(char drive in "CDEFGHI")yield return drive+":\\SteamLibrary";
        foreach(RegistryKey root in new RegistryKey[]{Registry.CurrentUser,Registry.LocalMachine}){
            foreach(string key in new string[]{@"Software\Valve\Steam",@"SOFTWARE\WOW6432Node\Valve\Steam"}){
                try{using(var k=root.OpenSubKey(key)){if(k!=null){object v=k.GetValue("SteamPath")??k.GetValue("InstallPath");if(v!=null)yieldReturnPaths.Add(Convert.ToString(v));}}}
                catch(Exception){}
            }
        }
        foreach(string p in yieldReturnPaths)yield return p;
    }
    static readonly List<string> yieldReturnPaths=new List<string>();
    static string FindGame(string explicitPath){
        if(!string.IsNullOrWhiteSpace(explicitPath)){
            string p=Path.GetFullPath(explicitPath.Trim(' ','\"'));
            Need(File.Exists(Path.Combine(p,IndexName)) && File.Exists(Path.Combine(p,"DetroitBecomeHuman.exe")),"Game folder must contain DetroitBecomeHuman.exe and BigFile_PC.idx: "+p);
            return p;
        }
        var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(string root in CandidateRoots()){
            var paths=new List<string>{root,Path.Combine(root,"steamapps","common","Detroit Become Human")};
            string libs=Path.Combine(root,"steamapps","libraryfolders.vdf");
            if(File.Exists(libs)){
                try{string s=File.ReadAllText(libs);foreach(Match m in SteamLibrary.Matches(s)){string path=m.Groups[1].Value.Replace("\\\\","\\");paths.Add(Path.Combine(path,"steamapps","common","Detroit Become Human"));}}
                catch(IOException){}
            }
            foreach(string p in paths){if(!seen.Add(p))continue;if(File.Exists(Path.Combine(p,IndexName))&&File.Exists(Path.Combine(p,"DetroitBecomeHuman.exe")))return p;}
        }
        return null;
    }
    // Expose the existing Steam / explicit-folder detection to the PowerShell UI.
    // No game archive, font, translation, or installation logic is changed.
    public static void Diagnose(string basedir,string suppliedPath){
        BaseDir=basedir;
        string game=FindGame(suppliedPath);
        Need(game!=null,"Game folder not found");
        Console.WriteLine("Game: "+game);
        Console.WriteLine("READ-ONLY compatibility inspection. Game files will not be modified.");
        string idxFile=Path.Combine(game,IndexName);
        byte[] idx=File.ReadAllBytes(idxFile);
        Need(idx.Length<=MaxIndex && HasHead(idx,0,"QUANTICDREAMTABINDEX"),"Invalid game index header");
        var resources=LoadRows(Path.Combine(BaseDir,"enginedata","translation_data.json.gz"));
        string type,sha;
        AssertVersion(idx,game,resources,out type,out sha);
        Console.WriteLine("COMPATIBLE: "+type+". The installation checks will accept this build.");
    }
    public static string DetectGame(string basedir,string suppliedPath){
        BaseDir=basedir;
        return FindGame(suppliedPath);
    }
    public static void Run(string basedir,string command,string suppliedPath){
        BaseDir=basedir;
        string game=FindGame(suppliedPath);
        if(game==null){
            Console.Write("Game not found automatically. Enter full Detroit Become Human folder path: ");
            game=FindGame(Console.ReadLine());
        }
        Console.WriteLine("Game: "+game);
        string action=(command??"").ToLowerInvariant();
        if(action=="install")Install(game);
        else if(action=="uninstall")Uninstall(game);
        else if(action=="diagnose")Diagnose(basedir,game);
        else throw new ArgumentException("Unknown action: "+action);
    }
}
